//
// Created by TekuConcept on October 20, 2021
//

using System.IO;
using UnrealBuildTool;

public class NodeJS : ModuleRules
{
	public NodeJS(ReadOnlyTargetRules target) : base(target)
	{
		Type = ModuleType.External;
		PublicIncludePaths.AddRange(new[]
		{
			Path.Combine(ModuleDirectory, "Public/node"),
			Path.Combine(ModuleDirectory, "Public/uv"),
			Path.Combine(ModuleDirectory, "Public/v8")
		});

		if (target.Platform == UnrealTargetPlatform.Win64)
		{
			PublicAdditionalLibraries.Add(Path.Combine(
				ModuleDirectory, "x64", "Release", "libnode.lib"));
			PublicDelayLoadDLLs.Add("libnode.dll");
			RuntimeDependencies.Add("$(PluginDir)/Binaries/ThirdParty/NodeJS/Win64/libnode.dll");
        }
        else if (target.Platform == UnrealTargetPlatform.Mac)
        {
            PublicDelayLoadDLLs.Add(Path.Combine(ModuleDirectory, "Mac", "Release", "libnode.dylib"));
            RuntimeDependencies.Add("$(PluginDir)/Source/ThirdParty/NodeJS/Mac/Release/libnode.dylib");
        }
        else if (target.Platform == UnrealTargetPlatform.Linux)
		{
			string SoPath = Path.Combine("$(PluginDir)", "Binaries", "ThirdParty", "libnode", "Linux", "x86_64-unknown-linux-gnu", "libnode.so");
			PublicAdditionalLibraries.Add(SoPath);
			PublicDelayLoadDLLs.Add(SoPath);
			RuntimeDependencies.Add(SoPath);
		}
	}
}
